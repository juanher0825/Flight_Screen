package ui;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Region;
import javafx.stage.StageStyle;
import model.Flights;

public class FlightController {
	
	private Flights flights;
	private String label1="";
	private String label2="";
	private String label3="";
	private long delayedTime;

    @FXML
    private TextField flightsField;

    @FXML
    private TextField searchField;

    @FXML
    private Label dateColumn;

    @FXML
    private Label airlineColumn;

    @FXML
    private Label flightColumn;

    @FXML
    private Label currentTime;

    @FXML
    void buttomAirline(ActionEvent event) {
    	try {
    		delayedTime = System.currentTimeMillis();
			flights.SortByAirline();
			currentTime.setText("Time: "+flights.calculateTime(delayedTime));
			showTable();
			
		}catch(NullPointerException e) {
			Alert alert = new Alert(AlertType.INFORMATION, "Please create some flights first", ButtonType.OK);
        	alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
        	alert.show();
        
    	}

    }

    @FXML
    void buttomDate(ActionEvent event) {
    	
    	try{
    		delayedTime = System.currentTimeMillis();
			flights.sortByDate();
			currentTime.setText("Time: "+flights.calculateTime(delayedTime));
			showTable();
		}catch(NullPointerException e) {
			Alert alert = new Alert(AlertType.INFORMATION, "Please create some flights first", ButtonType.OK);
        	alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
        	alert.show();
        	
    	} 

    }

    @FXML
    void buttomFlight(ActionEvent event) {
    	try{
    		delayedTime = System.currentTimeMillis();
			flights.sortByFlightId();
			currentTime.setText("Time: "+flights.calculateTime(delayedTime));
			showTable();
		}catch(NullPointerException e) {
			Alert alert = new Alert(AlertType.INFORMATION, "Please create some flights first", ButtonType.OK);
        	alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
        	alert.show();
    	} 

    }

    @FXML
    void buttomGate(ActionEvent event) {
    	try{
    		delayedTime = System.currentTimeMillis();
			flights.sortByBoardingGate();
			currentTime.setText("Time: "+flights.calculateTime(delayedTime));
			showTable();
		}catch(NullPointerException e) {
			Alert alert = new Alert(AlertType.INFORMATION, "Please create some flights first", ButtonType.OK);
        	alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
        	alert.show();
    	}

    }

    @FXML
    void buttomTime(ActionEvent event) {
    	try{
    		delayedTime = System.currentTimeMillis();
			flights.sortByDeparture();
			currentTime.setText("Time: "+flights.calculateTime(delayedTime));
			showTable();
		}catch(NullPointerException e) {
			Alert alert = new Alert(AlertType.INFORMATION, "Please create some flights first", ButtonType.OK);
        	alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
        	alert.show();
    	} 
    }

    @FXML
    void buttomTo(ActionEvent event) {
    	try {
			delayedTime = System.currentTimeMillis();
			flights.SortByDesnitationCity();
			currentTime.setText("Time: "+flights.calculateTime(delayedTime));
			showTable();
		} catch (NullPointerException e) {
			Alert alert = new Alert(AlertType.INFORMATION, "Please create some flights first", ButtonType.OK);
        	alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
        	alert.show();
		}
    }

    @FXML
    void generate(ActionEvent event) throws IOException {
    	int value = 0;
		try {
    		value = Integer.parseInt(flightsField.getText());
    		flights = new Flights(flights.generateFlightsList(value));
    	}catch(NumberFormatException e) {
    		Alert alert = new Alert(AlertType.INFORMATION, "Please write a correct number", ButtonType.OK);
        	alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
        	alert.show();
    	} 
		showTable();
    

    }

    @FXML
    void nextPage(ActionEvent event) {
    	label1="";
		label2="";
		label3="";
    	if(flights != null) {
    		for (int I = 10; I < flights.getFlights().size(); I++) {
    			label1 += flights.getFlights().get(I).getDate() + "\t\t\t" + flights.getFlights().get(I).getDepartureTime()
    					+ "\n";
    			dateColumn.setText(label1);

    			label2 += flights.getFlights().get(I).getId() + "\t\t\t\t\t" + flights.getFlights().get(I).getDestinationCity()
    					+ "\n";
    			flightColumn.setText(label2);

    			label3 += flights.getFlights().get(I).getAirline() + "\n";
    			airlineColumn.setText(label3);
    		}
    	}

    }

    @FXML
    void previousPage(ActionEvent event) {
    	if (flights != null) {
    		showTable();
    	}
    }

    @FXML
    void search(ActionEvent event) {

    }
    
    @FXML
    
    void initialize() throws IOException {
    	flights = new Flights(null);
    }
    
		
    
    public void showTable() {
		label1="";
		label2="";
		label3="";
		if(flights.getFlights().size() <= 10) {
		for (int I = 0; I < flights.getFlights().size(); I++) {
			label1 += flights.getFlights().get(I).getDate() + "\t\t\t" 
					+ flights.getFlights().get(I).getDepartureTime() + "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
					+ flights.getFlights().get(I).getBoardingGate()
					+"\n";
			dateColumn.setText(label1);

			label2 += flights.getFlights().get(I).getId() + "\t\t\t\t\t" 
					+ flights.getFlights().get(I).getDestinationCity()
					+ "\n";
			flightColumn.setText(label2);

			label3 += flights.getFlights().get(I).getAirline() + "\n";
			airlineColumn.setText(label3);
		}
		}else if(flights.getFlights().size() > 10) {
			for (int I = 0; I < 10; I++) {
				label1 += flights.getFlights().get(I).getDate() + "\t\t\t" 
						+ flights.getFlights().get(I).getDepartureTime() + "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
						+ flights.getFlights().get(I).getBoardingGate()
						+"\n";
				dateColumn.setText(label1);

				label2 += flights.getFlights().get(I).getId() + "\t\t\t\t\t" 
						+ flights.getFlights().get(I).getDestinationCity()
						+ "\n";
				flightColumn.setText(label2);

				label3 += flights.getFlights().get(I).getAirline() + "\n";
				airlineColumn.setText(label3);
			}
		}
	}

}

